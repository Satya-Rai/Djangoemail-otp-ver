from django.shortcuts import render , redirect,HttpResponse,HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth import authenticate , login as loginUser  , logout, update_session_auth_hash
from django.contrib.auth.forms import AuthenticationForm , PasswordChangeForm
# Create your views here.
from app.forms import TODOForm,signupForm,SetPasswordForm,forget_passwordForm,Password_rest_form
#from django.views.generic import TemplateView, FormView, CreateView
#from django.urls import reverse_lazy, reverse 
from app.models import TODO,MyCustomModel,user_otp
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
import random
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
#from django.template.loader import render_to_string
#from .tokens import account_activation_token
#from django.core.mail import send_mail
# from .utils import *
# import uuid
from django.contrib.auth import get_user_model
from functools import lru_cache
from django.views.decorators.cache import cache_page


#[(u.email, u.is_active, u.has_usable_password()) for u in get_user_model().objects.all()]


from todo import settings
User = get_user_model()

#@cache_page(60)
@login_required(login_url='login')
def home(request):
    if request.user.is_authenticated:
        user = request.user
        form = TODOForm()
        todos = TODO.objects.filter(user = user).order_by('priority')
        #print(todos.__dict__)
        if (request.session.has_key('uid')):
            res = request.session['uid']
            print(res)
            return render(request , 'index.html' , context={'form' : form , 'todos' : todos, })
        else:
            return redirect('login')

def login(request):
    
    if request.method == 'GET':
        form1 = AuthenticationForm()
        context = {
            "form" : form1
        }
        return render(request , 'login.html' , context=context )
    else:
        form = AuthenticationForm(data=request.POST)
        print(form.is_valid())
        
        #s = MyCustomModel.objects.filter(email_id =request.POST['email'], password = request.POST['password'])
        
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            data=request.POST.get('username')
            #print(data)
            user = authenticate(username = username , password = password)
        

            if user is not None:
                loginUser(request , user)
                messages.success(request, f'You Have Logged In Successfully ')
                request.session['uid'] = request.POST.get('user.id') 
                return redirect('home')
        else:
            context = {
                "form" : form
            }
            return render(request , 'login.html' , context=context )

#=====================Verification via OTP=============================================================================================
#@lru_cache(maxsize = 32)
def signup(request):

    if request.method == 'GET':
        form = signupForm()
        context = {
            "form" : form
        }
        return render(request , 'signup.html' , context=context)
    else:
        #print(request.POST)
        form = signupForm(request.POST)  
        context = {
            "form" : form
        }
        if form.is_valid():
            user = form.save()
            user.is_active=False  #now user is not active thus can,t login bec we have to verify user with OTP
            user.save()
            user_id = user.id
            print(user)
            if user is not None:
                otp_send(user_id)
                messages.success(request, f'Otp Has Sent Successfully To Ur Mail.Check Ur Mail')
            return render(request, 'otp_check.html', {'otp':True, 'usr':user})
        else:
            return render(request , 'signup.html' , context=context)

def otp_send(user_id):
  

    usr = MyCustomModel.objects.get(id = user_id)
    #usr = request.POST.get('username')
    usr_otp = random.randint(100000,999999)
    print(usr_otp)

   
    user_otp.objects.create(user = usr, otp = usr_otp)
    msg = f'Hii {usr.username} Your otp is {usr_otp}'

    send_mail(
        "Welcome to our ToDo App. plz verify your mail",
                 msg,
                 settings.EMAIL_HOST_USER,
                 [usr.email,],
                 fail_silently = False,
    )



# def password_reset(request, id):
#     if request.method == 'GET':
#         form = PasswordUpdateForm()
#         context = {
#             "form" : form
#         }
#         return render(request , 'signup.html' , context=context)
#     else:
#         #print(request.POST)
#         form = PasswordUpdateForm(request.POST)  
#         context = {
#             "form" : form
#         }
#         if form.is_valid():
#             user = form.save()
#             user.is_active=False  #now user is not active thus can,t login bec we have to verify user with OTP
#             user.save()
#             user_id = user.id
#             print(user)
#             if user is not None:
#                 otp_send(user_id)
#                 messages.success(request, f'Otp Has Sent Successfully To Ur Mail.Check Ur Mail')
#             return render(request, 'otp_check.html', {'otp':True, 'usr':user})
#         else:
#             return render(request , 'signup.html' , context=context)

# def otp_send(user_id):
  

#     usr = MyCustomModel.objects.get(id = user_id)
#     #usr = request.POST.get('username')
#     usr_otp = random.randint(100000,999999)
#     print(usr_otp)

   
#     user_otp.objects.create(user = usr, otp = usr_otp)
#     msg = f'Hii {usr.username} Your otp is {usr_otp}'

#     send_mail(
#         "Welcome to our ToDo App. plz verify your mail",
#                  msg,
#                  settings.EMAIL_HOST_USER,
#                  [usr.email,],
#                  fail_silently = False,
#     )
    




def verify(request):
    if request.method == 'POST':
        get_otp = request.POST.get('otp')
        if get_otp:
            get_usr = request.POST.get('usr')
            #usr = MyCustomModel.objects.get(email=request.POST.get('email'))
            usr = MyCustomModel.objects.get(email = get_usr)
        
            if int(get_otp) == user_otp.objects.filter(user=usr).last().otp:
                usr.is_active = True
                usr.save()
                messages.success(request, f'Account is Created For {usr.username}')

                return redirect('login')
            else:
                messages.warning(request, f'You Entered a Wrong OTP')
                return render(request, 'otp_check.html', {'otp': True, 'usr': usr})
        




























#===========CRUD OPerations=============================================================================================================
@login_required(login_url='login')
def add_todo(request):
    if request.user.is_authenticated:
        user = request.user
        #print(user)
        form = TODOForm(request.POST,request.FILES)
        #print(request.POST, request.FILES) 
        if form.is_valid():
            print(form.cleaned_data)
            todo = form.save(commit=False)
            todo.user = user
            todo.save()
            #print(todo)
            return redirect("home")
        else: 
            return render(request , 'index.html' , context={'form' : form})


def delete_todo(request , id ):
    print(id)
    TODO.objects.get(pk = id).delete()
    return redirect('home')

def change_todo(request , id  , status):
    todo = TODO.objects.get(pk = id)
    todo.status = status
    todo.save()
    return redirect('home')


@login_required(login_url='login')
def change_password(request ):
    if request.user.is_authenticated:
        if request.method == 'POST':
            fm = PasswordChangeForm(user=request.user, data = request.POST)
            if fm.is_valid():
                fm.save()
                #update_session_auth_hash(request, fm.user)
            return redirect('home')
        else:
            fm = PasswordChangeForm(user = request.user)
        #user = request.user
        return render(request, 'changepass.html', {'form': fm})

# def password_reset(request ):
#     if request.user.is_authenticated:
#         if request.method == 'POST':
#             fm = SetPasswordForm(user=request.user, data = request.POST)
#             if fm.is_valid():
#                 fm.save()
#                 #update_session_auth_hash(request, fm.user)
#             return redirect('home')
#         else:
#             fm = SetPasswordForm(user = request.user)
#         #user = request.user
#         return render(request, 'password_reset.html', {'form': fm})



def signout(request):
    request.session.clear()
    logout(request)
    return redirect('login')

#===========Reset Password via OTP==========================================================================================================
def forget_password(request):
    if request.method == 'GET':
        form = forget_passwordForm()
        context = {
            "form" : form
        }
        return render(request , 'forget_password.html' , context=context)
    else:
        form = forget_passwordForm(request.POST)
        
        email = request.POST.get('email')
        user_email = MyCustomModel.objects.filter(email = email)
        if user_email:
            user = MyCustomModel.objects.get(email=email)
            user.is_active = False
            user.save()
            user_id = user.id
            request.session['email'] = request.POST['email']
            if user is not None:
                    otp_send(user_id)
                    messages.success(request, f'Otp Has Sent Successfully To Ur Mail.Check Ur Mail')
                    return render(request, 'otp_check1.html', {'otp':True, 'usr':user})
        else:
            messages.warning(request,f'invalid user_email, pln enter correct email')
            return render(request, 'forget_password.html', {'form':form})
def verify1(request):
     if request.session.has_key('email'):
        email = request.session['email']
        get_otp = request.POST.get('otp')
        if get_otp:
            get_usr = request.POST.get('usr')
            usr = MyCustomModel.objects.get(email=get_usr)

            if int(get_otp) == user_otp.objects.filter(user=usr).last().otp:
                usr.is_active = True
                usr.save()
                messages.success(request, f'your Email is verified')
                return redirect('password_reset')
            else:
                messages.warning(request, f'you have entered a wrong otp')
                return render(request, 'otp_check1.html', {'otp':True, 'usr': usr})


def password_reset(request):
    if request.session.has_key('email'):
        email = request.session['email']
        print(email)
        user = MyCustomModel.objects.get(email=email)
        if request.method == 'POST':
            form = Password_rest_form(request.POST)
            new_password = request.POST.get('new_password')
            confirm_password = request.POST.get('confirm_password')
            if not new_password:
                messages.warning(request, f'Enter New Password')
            elif not confirm_password:
                messages.warning(request,f'plz Enter Your Confirm Password')
            elif new_password == user.password:
                messages.warning(request, f'Password Already Exists!!!!!Plz Enter New Password ')
            elif new_password != confirm_password:
                messages.warning(request, f'Password is not matched')
            else: 
                user.password = new_password
                user.save()
                messages.success(request,f'Password changed successfully')
                return redirect('login')
        else:
            form = Password_rest_form()
            return render(request, 'password_reset.html', {'form':form})


            

    
    
        