from django.contrib import admin
from django.urls import path
from app.views import home , login , signup , add_todo , signout , delete_todo, change_todo, change_password,otp_send,verify, forget_password,verify1,password_reset
from django.contrib.auth import views as auth_views
#resend_otp


urlpatterns = [
   path('' , home , name='home' ), 
   path('login/' ,login  , name='login'), 
   path('signup/' , signup, name='signup' ), 
   path('add-todo/' , add_todo ), 
   path('delete-todo/<int:id>/' , delete_todo ), 
   path('change-status/<int:id>/<str:status>/' , change_todo ), 
   path('logout/' , signout ),
   path('changepass/', change_password, name='changepass'),
   path('otp_send/', otp_send, name='otp_send'),
   path('verify/', verify, name='verify'),
    
   #path('password_reset/', password_reset, name='password_reset'),
   # path("password_reset/", auth_views.PasswordResetView.as_view(template_name='password_reset.html'), name="password_reset"),
   # path("password_reset/done/", auth_views.PasswordResetDoneView.as_view(template_name='password_reset_done.html'), name="password_reset_done"),
   # path("password_reset_confirm/<uidb64>/<token>/", auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html'), name="password_reset_confirm"),
   # path("password_reset_complete/", auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'), name="password_reset_complete"),
   #path('resendOTP', resend_otp), 
   #path('verify/', verify, name='verify')
   #path('activate/<uidb64>/<token>', activate, name='activate')
   #path('activate/' , verify, name ='activate' )
   path('forget_password/', forget_password, name='forget_password'),
   #path('otp1/', otp1, name='otp1'),
   path('verify1/', verify1, name='verify1'),
   path('password_reset/', password_reset, name='password_reset'),
]